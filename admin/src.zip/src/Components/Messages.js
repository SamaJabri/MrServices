import React from 'react';

const Messages = () =>
{
    return (
        <div>
Message
        </div>
    );
};

export default Messages;